import dell from "../img/dell.webp"
import hp from "../img/hp.webp"
import msi from "../img/msi.webp"
import lenovo from "../img/lenovo.jpg"

export const Images = {
  dell: dell,
  hp: hp,
  msi: msi,
  lenovo: lenovo
};
