import React from 'react'

export default function Mobiles() {
  return (
    <div>Mobiles</div>
  )
}
