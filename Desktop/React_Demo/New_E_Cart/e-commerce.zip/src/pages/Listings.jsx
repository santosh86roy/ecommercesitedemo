import React from 'react'

export default function Listings() {
  return (
    <div>Listings</div>
  )
}
