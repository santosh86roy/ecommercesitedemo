import React from 'react'

export default function Laptops() {
  return (
    <div>Laptops</div>
  )
}
