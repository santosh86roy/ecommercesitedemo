import React from 'react'

export default function Earphones() {
  return (
    <div>Earphones</div>
  )
}
